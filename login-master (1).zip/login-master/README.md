Cara MEmbuat MenuLogin Dengan Termux

Cara Install nya 
git clone 
https://github.com/kumpulanremaja/login
$cd login-termuxv2fx
$python2 setup.py
$cd ..
$python2 useradd.py
###ENJOY###


command:
$useradd : Untuk Menambahkan user Baru
$passwd : Untuk Mengganti Pw Baru
$info : Untuk Menampilkan Data User
$me : Untuk Melihat Author/Pembuat Script ini


selengkapnya bisa baca di https://www.kumpulanremaja.com/2019/08/cara-membuat-login-di-aplikasi-termux.html
